﻿using Application;
using Application.UseCases.Commands;
using Application.UseCases.DTO;
using DataAccess;
using Domain;
using FluentValidation;
using Implementation.Validators;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Implementation.UseCases.Commands
{
    public class UpdateAReservationCommand : DbContextBase, IUpdateAReservationCommand
    {
        private IApplicationActor actor;
        private ReservationUpdateValidator validator;
        public UpdateAReservationCommand(HotelContext context, IApplicationActor actor, ReservationUpdateValidator validator) : base(context)
        {
            this.actor = actor;
            this.validator = validator;
        }

        public int Id => 6;

        public string Name => "Update a reservation.";

        public string Description => "Update a reservation after checking if a new date is available.";

        public void Execute(ReservationUpdateDTO request)
        {
            


        }
    }
}

