﻿using Application;
using Application.Exceptions;
using Application.UseCases.Commands;
using Application.UseCases.DTO;
using DataAccess;
using DataAccess.Migrations;
using Domain;
using FluentValidation;
using Implementation.Validators;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Implementation.UseCases.Commands
{
    public class MakeAReservationCommand : DbContextBase, IMakeAReservationCommand
    {
        private IApplicationActor actor;
        private ReservationValidator validator;
        public MakeAReservationCommand(HotelContext context, IApplicationActor actor, ReservationValidator validator) : base(context)
        {
            this.actor= actor;
            this.validator = validator;
        }   

        public int Id => 4;

        public string Name => "Make a reservation";

        public string Description => "";

        public void Execute(ReservationDTO request)
        {
            
            validator.ValidateAndThrow(request);
           

            var roomType = Context.RoomTypes
                .Where(rt => rt.Id == request.roomTypeId)
                .Select(rt => new { rt.MaxCapacity })
                .FirstOrDefault();

            if (roomType == null)
            {
                throw new Exception("Room type not found.");
            }

            
            int roomsNeeded = (int)Math.Ceiling((double)request.numberOfPeople / roomType.MaxCapacity);

            
            var availableRoomIds = Context.Rooms
                .Where(r => r.TypeOfRoom.Id == request.roomTypeId)
                .Where(r => !Context.ReservedRooms
                    .Any(rr => rr.RoomId == r.Id &&
                               rr.Reservation.IsActive &&
                               ((rr.Reservation.CheckIn <= request.DateTo && rr.Reservation.CheckOut >= request.DateFrom))))
                .Select(r => r.Id)
                .Take(roomsNeeded)  
                .ToList();

            if (availableRoomIds.Count < roomsNeeded)
            {
                throw new ReservationNotPossibleException("We are sorry, there are not enough rooms available.");
            }

            
            var newReservation = new Reservation
            {
                CheckIn = request.DateFrom,
                CheckOut = request.DateTo,
                GuestId = actor.Id,
                IsActive = true,
                CreatedAt = DateTime.Now
            };

            Context.Reservations.Add(newReservation);
            Context.SaveChanges();  

            
            foreach (var roomId in availableRoomIds)
            {
                var reservedRoom = new ReservedRoom
                {
                    ReservationId = newReservation.Id,
                    RoomId = roomId
                };

                Context.ReservedRooms.Add(reservedRoom);
            }

           
            Context.SaveChanges();
        }
    }
}
