﻿using Application.Exceptions;
using Application.UseCases.Commands;
using DataAccess;
using Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Implementation.UseCases.Commands
{
    public class CancelReservationCommand : DbContextBase, ICancelReservationCommand
    {
        public CancelReservationCommand(HotelContext context) : base(context)
        {
        }

        public int Id => 5;

        public string Name => "Cancel reservation";

        public string Description => "Cancel reservation.";

        public void Execute(int request)
        {
            var reservation = Context.Reservations
        .FirstOrDefault(x => x.Id == request );

            if (reservation == null)
            {
                throw new ReservationNotFoundException("Reservation not found.");
            }

            
            reservation.IsActive = false;

            var reservedRooms = Context.ReservedRooms
                .Where(rr => rr.ReservationId == request)
                .ToList();

            if (reservedRooms.Any())
            {
                Context.ReservedRooms.RemoveRange(reservedRooms);
            }


            Context.SaveChanges();


        }
    }
}
