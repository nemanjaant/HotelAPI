﻿using Application.UseCases.DTO;
using Application.UseCases.Queries;
using DataAccess;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Implementation.UseCases.Queries
{
    public class SearchAuditLogQuery : DbContextBase, ISearchAuditLogQuery
    {
        public SearchAuditLogQuery(HotelContext context) : base(context)
        {
        }

        public int Id => 7;

        public string Name => "Search Audit Log Query";

        public string Description => "Search by keyword and date range.";

        public List<AuditLogDto> Execute(SearchAuditLogDto request)
        {
            
            var query = Context.LogEntries.AsQueryable();

            
            if (!string.IsNullOrEmpty(request.Keyword))
            {
                query = query.Where(x => x.Actor.Contains(request.Keyword)|| x.UseCaseName.Contains(request.Keyword)|| x.UseCaseData.Contains(request.Keyword));
            }

            
            if (request.DateFrom != null && request.DateFrom < request.DateTo)
            {
                query = query.Where(x => x.CreatedAt >= request.DateFrom);
            }

            
            if (request.DateTo != null && request.DateTo > request.DateFrom)
            {
                query = query.Where(x => x.CreatedAt <= request.DateTo);
            }

           
            var auditLogs = query.Select(x => new AuditLogDto
            {
                Actor = x.Actor,
                UseCaseName = x.UseCaseName,
                UseCaseData = x.UseCaseData,
                CreatedAt = x.CreatedAt
            }).ToList();

            return auditLogs;
        }

    }
}
