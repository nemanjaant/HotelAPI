﻿using Application.UseCases.DTO;
using Application.UseCases.Queries;
using DataAccess;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Microsoft.Extensions.Logging.EventSource.LoggingEventSource;

namespace Implementation.UseCases.Queries
{
    public class SearchRoomsQuery : DbContextBase, ISearchRoomsQuery
    {
        public SearchRoomsQuery(HotelContext context) : base(context)
        {
        }

        public int Id => 3;

        public string Name => "Search Rooms Query";

        public string Description => "Searching available rooms based on keyword (room type name) and date range (counting available units for a given date range).";

        public IEnumerable<RoomDTO> Execute(RoomSearchDTO request)
        {
            var query = Context.RoomTypes
            .Where(rt => rt.IsActive && rt.TypeName.Contains(request.Keyword));

            return query.Select(rt => new RoomDTO
            {
                Name = rt.TypeName,
                Price = Context.Prices
                    .Where(p => p.RoomTypeId == rt.Id && p.ValidTo == null)
                    .Select(p => p.PriceValue)
                    .FirstOrDefault(),
                AvailableUnits = Context.Rooms
                    .Where(r => r.TypeOfRoom.Id == rt.Id && r.IsAvailable)
                    .Count() - Context.ReservedRooms
                    .Where(rr => rr.Room.TypeOfRoom.Id == rt.Id &&
                                 ((rr.Reservation.CheckIn <= request.DateTo && rr.Reservation.CheckOut >= request.DateFrom))) 
                    .Select(rr => rr.RoomId)
                    .Distinct()
                    .Count() 
            })
            .ToList();

        }
    }
}
