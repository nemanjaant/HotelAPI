﻿using Application.UseCases.DTO;
using FluentValidation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Implementation.Validators
{
    public class ReservationValidator : AbstractValidator<ReservationDTO>
    {
        public ReservationValidator()
        {
            
            RuleFor(reservation => reservation.roomTypeId)
                .GreaterThan(0)
                .WithMessage("Room Type Id must be greater than 0.");

            RuleFor(reservation => reservation.numberOfPeople)
                .GreaterThan(0)
                .WithMessage("Number of people must be greater than 0.");

                        
            RuleFor(reservation => reservation.DateFrom)
                .GreaterThan(DateTime.Now)
                .WithMessage("Check-in date must be in the future.");

            
            RuleFor(reservation => reservation.DateTo)
                .GreaterThanOrEqualTo(reservation => reservation.DateFrom)
                .WithMessage("Check-out date must be greater than or equal to check-in date.");
        }
    }
}
