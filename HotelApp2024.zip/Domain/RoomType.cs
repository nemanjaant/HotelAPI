﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain
{
    public class RoomType : Entity
    {

        public string TypeName { get; set; }
        public int MaxCapacity { get; set; }

        public virtual ICollection<Room> Rooms { get; set; }
        public virtual ICollection<Image> Images { get; set; }
        public virtual ICollection<Price> Prices { get; set; }
    }
}
