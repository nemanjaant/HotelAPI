﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain
{
    public class Reservation : Entity
    {
        public DateTime CheckIn { get; set; } 
        public DateTime CheckOut { get; set; }
        public int GuestId { get; set; }
        public bool IsActive { get; set; }
       

        public virtual User Guest { get; set; }

        public virtual ICollection<Room> Rooms { get; set;} = new HashSet<Room>();
        
    }
}
