﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain
{
    public class Price : Entity
    {
        public DateTime ValidFrom { get; set; }
        public DateTime? ValidTo { get; set; }
        public double PriceValue { get; set; }
        public int RoomTypeId { get; set; }

        public virtual RoomType RoomType { get; set; }
    }
}
