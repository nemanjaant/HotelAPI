﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.UseCases.DTO
{
    public class RoomDTO
    {
        public string Name { get; set; }
        public double Price { get; set; }
        public int AvailableUnits { get; set; }
    }
}
