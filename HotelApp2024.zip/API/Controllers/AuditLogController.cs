﻿using Application;
using Application.UseCases.DTO;
using Application.UseCases.DTO.Read;
using Application.UseCases.Queries;
using Implementation;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuditLogController : ControllerBase
    {
        private UseCaseHandler handler;
        private IApplicationActor actor;

        public AuditLogController(UseCaseHandler handler, IApplicationActor actor)
        {
            this.handler = handler;
            this.actor = actor;
        }

        [HttpGet]
        [Authorize]
        public IActionResult Get([FromQuery] SearchAuditLogDto search, [FromServices] ISearchAuditLogQuery query)
        {
            
            return Ok(handler.HandleQuery(query, search));
        }
    }
}
