﻿using API.Extensions;
using Application.Exceptions;
using Application.UseCases.Commands;
using Application.UseCases.DTO;
using Domain;
using FluentValidation;
using Implementation;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ReservationController : ControllerBase
    {
        private UseCaseHandler handler;

        public ReservationController(UseCaseHandler handler)
        {
            this.handler = handler;
        }

        [HttpPost]
        [Authorize]
        public IActionResult Post([FromBody] ReservationDTO reservation, [FromServices] IMakeAReservationCommand command)
        {
            try
            {
                handler.HandleCommand(command, reservation);
                return StatusCode(201);

            }
            catch (ReservationNotPossibleException ex)
            {
                return Conflict(new { Message = ex.Message });
            }

            catch (Exception ex)
            {
                return StatusCode(500, new { Message = "An error occurred: " + ex.Message });
            }
        }

        
        [HttpPut]
        [Authorize]
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE api/<ReservationController>/5
        [HttpDelete("{id}")]
        [Authorize]
        public IActionResult Delete(int id, [FromServices] ICancelReservationCommand command)
        {
            try
            {
                handler.HandleCommand(command, id);
                return StatusCode(201);

            }
            catch (ReservationNotFoundException ex)
            {
                return NotFound(new { Message = ex.Message });
            }

            catch (Exception ex)
            {
                return StatusCode(500, new { Message = "An error occurred: " + ex.Message });
            }
        }
    }
}
