﻿using Application.UseCases.DTO;
using Application.UseCases.DTO.Read;
using Application.UseCases.Queries;
using Implementation;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RoomsController : Controller
    {
       
        private UseCaseHandler handler;

        public RoomsController(UseCaseHandler handler)
        {
            this.handler = handler;
        }

        [HttpGet]
        [Authorize]
        public IActionResult Get([FromQuery] RoomSearchDTO search, [FromServices] ISearchRoomsQuery query)
        {
            return Ok(handler.HandleQuery(query, search));
        }

        
        
    }
}
