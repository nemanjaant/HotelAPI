﻿using API.Extensions;
using Application.UseCases.Commands;
using Application.UseCases.DTO;
using Application.UseCases.DTO.Read;
using Application.UseCases.Queries;
using FluentValidation;
using Implementation;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Reflection.Metadata;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory;

namespace API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UsersController : ControllerBase
    {
        private UseCaseHandler handler;

        public UsersController(UseCaseHandler handler)
        {
            this.handler = handler;
        }


        [HttpGet]
        [Authorize]
        public IActionResult Get([FromQuery] KeywordSearchDTO search, [FromServices] ISearchUsersQuery query)
        {
            return Ok(handler.HandleQuery(query, search));
        }

        //registration
        [HttpPost]
        [AllowAnonymous]
        public IActionResult Post([FromBody] UserDTO dto, [FromServices] IRegisterUserCommand command)
        {
            try
            {
                handler.HandleCommand(command, dto);
                return StatusCode(201);

            }
            catch (ValidationException ex)
            {
                return UnprocessableEntity(ex.Errors.AsUnprocessableEntity());
            }
            
            
        }
    }
}
