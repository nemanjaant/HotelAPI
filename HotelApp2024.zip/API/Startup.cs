
using API.Extensions;
using Application.Logging;
using Application.UseCases.Queries;
using DataAccess;
using Implementation;
using Implementation.Logging;
using Implementation.UseCases.Queries;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.OpenApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Bugsnag.AspNet.Core;
using Application;
using Microsoft.AspNetCore.Http;
using API.Jwt;
using System.IdentityModel.Tokens.Jwt;
using Newtonsoft.Json;
using API.Jwt.TokenStorage;
using Implementation.Validators;

namespace API
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {

            //my configuration
            var settings = new AppSettings();
            Configuration.Bind(settings);
            services.AddTransient<ITokenStorage, InMemoryTokenStorage>();
            services.AddTransient(x =>
            {
                var context = x.GetService<HotelContext>();
                var tokenStorage = x.GetService<ITokenStorage>();
                return new JwtManager(context, settings.Jwt.Issuer, settings.Jwt.SecretKey, 
                    settings.Jwt.DurationSeconds, tokenStorage);
            });

            services.AddBugsnag(configuration => {
                configuration.ApiKey = settings.BugSnagKey;
            });

            services.AddLogger();
            services.AddCommands();
            services.AddValidators();
            services.AddTransient(x =>
             {
              DbContextOptionsBuilder builder = new DbContextOptionsBuilder();
              builder.UseSqlServer(@"Data Source=.\SQLEXPRESS;Initial Catalog=HotelApp;Integrated Security=True");
              return new HotelContext(builder.Options);
             });

            

            
            services.AddBugsnag(configuration => {
                configuration.ApiKey = settings.BugSnagKey;
            });
            services.AddTransient<IExceptionLogger, ExceptionLogger>();
            services.AddSingleton<EfUseCaseLogger>();
            services.AddTransient<UseCaseHandler>();

            services.AddTransient<ISearchUsersQuery,SearchUsersQuery>();
            services.AddTransient<ISearchRoomsQuery, SearchRoomsQuery>();
            services.AddTransient<ISearchAuditLogQuery, SearchAuditLogQuery>();

            services.AddHttpContextAccessor();
            

            services.AddApplicationUser();
            services.AddJwt(settings);

            


            services.AddHttpContextAccessor();
            services.AddControllers();


            //my configuration - end
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new OpenApiInfo { Title = "API", Version = "v1" });
            });
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
                app.UseSwagger();
                app.UseSwaggerUI(c => c.SwaggerEndpoint("/swagger/v1/swagger.json", "API v1"));
            }

            app.UseRouting();

            app.UseAuthentication();
            app.UseAuthorization();
            



            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}
